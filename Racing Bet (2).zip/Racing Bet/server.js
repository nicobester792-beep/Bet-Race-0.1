const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const path = require('path');

app.use(express.static('public'));

// Game state
const rooms = {
    'room1': { players: {}, racing: false, winner: null },
    'room2': { players: {}, racing: false, winner: null },
    'room3': { players: {}, racing: false, winner: null },
    'room4': { players: {}, racing: false, winner: null }
};

const CAR_COLORS = ['#FF4444', '#4444FF', '#44FF44', '#FFAA00'];

io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('getRooms', () => {
        const roomsInfo = {};
        for (let roomId in rooms) {
            roomsInfo[roomId] = {
                playerCount: Object.keys(rooms[roomId].players).length,
                racing: rooms[roomId].racing
            };
        }
        socket.emit('roomsUpdate', roomsInfo);
    });

    socket.on('joinRoom', (data) => {
        const { roomId, playerData } = data;
        const room = rooms[roomId];

        if (!room) {
            socket.emit('error', 'Room not found');
            return;
        }

        if (Object.keys(room.players).length >= 4) {
            socket.emit('error', 'Room is full');
            return;
        }

        if (room.racing) {
            socket.emit('error', 'Race in progress');
            return;
        }

        // Assign car index based on join order
        const carIndex = Object.keys(room.players).length;
        
        room.players[socket.id] = {
            id: socket.id,
            name: playerData.name,
            money: playerData.money,
            carIndex: carIndex,
            bet: 0,
            betCar: null
        };

        socket.join(roomId);
        socket.currentRoom = roomId;

        // Send room state to all players in room
        io.to(roomId).emit('roomState', {
            players: room.players,
            racing: room.racing
        });

        // Update lobby
        broadcastRoomsUpdate();
    });

    socket.on('placeBet', (data) => {
        const roomId = socket.currentRoom;
        if (!roomId || !rooms[roomId]) return;

        const room = rooms[roomId];
        const player = room.players[socket.id];

        if (!player || room.racing) return;

        if (data.amount > player.money) {
            socket.emit('error', 'Not enough money');
            return;
        }

        player.bet = data.amount;
        player.betCar = data.carIndex;

        io.to(roomId).emit('roomState', {
            players: room.players,
            racing: room.racing
        });
    });

    socket.on('startRace', () => {
        const roomId = socket.currentRoom;
        if (!roomId || !rooms[roomId]) return;

        const room = rooms[roomId];
        
        // Check if all players have bet
        const allBet = Object.values(room.players).every(p => p.bet > 0);
        
        if (!allBet) {
            socket.emit('error', 'All players must place bets');
            return;
        }

        room.racing = true;
        io.to(roomId).emit('raceStart');

        // Simulate race
        const raceDuration = 5000 + Math.random() * 3000;
        const updateInterval = 50;
        const updates = raceDuration / updateInterval;
        
        const carPositions = [0, 0, 0, 0];
        let updateCount = 0;

        const raceInterval = setInterval(() => {
            updateCount++;
            
            // Random progress for each car
            for (let i = 0; i < 4; i++) {
                carPositions[i] += (Math.random() * 2 + 1);
            }

            io.to(roomId).emit('raceUpdate', carPositions);

            if (updateCount >= updates) {
                clearInterval(raceInterval);
                
                // Find winner
                const maxPos = Math.max(...carPositions);
                const winnerIndex = carPositions.indexOf(maxPos);
                
                room.winner = winnerIndex;

                // Calculate payouts
                for (let playerId in room.players) {
                    const player = room.players[playerId];
                    if (player.betCar === winnerIndex) {
                        // Win: 3x bet
                        player.money += player.bet * 2;
                    } else {
                        // Lose bet
                        player.money -= player.bet;
                    }
                    player.bet = 0;
                    player.betCar = null;
                }

                io.to(roomId).emit('raceEnd', {
                    winner: winnerIndex,
                    players: room.players
                });

                setTimeout(() => {
                    room.racing = false;
                    room.winner = null;
                    io.to(roomId).emit('roomState', {
                        players: room.players,
                        racing: room.racing
                    });
                }, 3000);
            }
        }, updateInterval);

        broadcastRoomsUpdate();
    });

    socket.on('leaveRoom', () => {
        const roomId = socket.currentRoom;
        if (!roomId || !rooms[roomId]) return;

        const room = rooms[roomId];
        const playerMoney = room.players[socket.id]?.money || 1000;
        
        delete room.players[socket.id];
        socket.leave(roomId);
        socket.currentRoom = null;

        // Reassign car indices
        let index = 0;
        for (let playerId in room.players) {
            room.players[playerId].carIndex = index++;
        }

        io.to(roomId).emit('roomState', {
            players: room.players,
            racing: room.racing
        });

        socket.emit('leftRoom', { money: playerMoney });
        broadcastRoomsUpdate();
    });

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        const roomId = socket.currentRoom;
        
        if (roomId && rooms[roomId]) {
            const room = rooms[roomId];
            delete room.players[socket.id];

            // Reassign car indices
            let index = 0;
            for (let playerId in room.players) {
                room.players[playerId].carIndex = index++;
            }

            io.to(roomId).emit('roomState', {
                players: room.players,
                racing: room.racing
            });

            broadcastRoomsUpdate();
        }
    });

    function broadcastRoomsUpdate() {
        const roomsInfo = {};
        for (let roomId in rooms) {
            roomsInfo[roomId] = {
                playerCount: Object.keys(rooms[roomId].players).length,
                racing: rooms[roomId].racing
            };
        }
        io.emit('roomsUpdate', roomsInfo);
    }
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} in your browser`);
});