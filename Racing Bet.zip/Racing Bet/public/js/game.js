// Game State
let playerData = {
    name: '',
    money: 1000
};

let currentRoom = null;
let selectedCar = null;
let socket = null;

// Load saved data
function loadPlayerData() {
    const saved = localStorage.getItem('betRacingPlayer');
    if (saved) {
        playerData = JSON.parse(saved);
        return true;
    }
    return false;
}

// Save player data
function savePlayerData() {
    localStorage.setItem('betRacingPlayer', JSON.stringify(playerData));
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = 'notification show ' + type;
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Switch screens
function switchScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screenId).classList.add('active');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Check if player data exists
    if (loadPlayerData()) {
        showMainMenu();
    } else {
        switchScreen('welcomeScreen');
    }

    // Welcome screen
    document.getElementById('startBtn').addEventListener('click', () => {
        const nameInput = document.getElementById('playerNameInput');
        const name = nameInput.value.trim();

        if (name.length < 2) {
            showNotification('Name must be at least 2 characters', 'error');
            return;
        }

        playerData.name = name;
        playerData.money = 1000;
        savePlayerData();
        showMainMenu();
    });

    // Settings
    document.getElementById('settingsBtn').addEventListener('click', () => {
        document.getElementById('settingsModal').classList.add('active');
        document.getElementById('newNameInput').value = playerData.name;
    });

    document.getElementById('closeSettingsBtn').addEventListener('click', () => {
        document.getElementById('settingsModal').classList.remove('active');
    });

    document.getElementById('saveNameBtn').addEventListener('click', () => {
        const newName = document.getElementById('newNameInput').value.trim();
        if (newName.length < 2) {
            showNotification('Name must be at least 2 characters', 'error');
            return;
        }
        playerData.name = newName;
        savePlayerData();
        document.getElementById('currentPlayerName').textContent = playerData.name;
        document.getElementById('settingsModal').classList.remove('active');
        showNotification('Name updated!', 'success');
    });

    // Room selection
    document.querySelectorAll('.btn-join').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const roomCard = e.target.closest('.room-card');
            const roomId = roomCard.dataset.room;
            joinRoom(roomId);
        });
    });

    // Leave room
    document.getElementById('leaveRoomBtn').addEventListener('click', () => {
        if (socket) {
            socket.emit('leaveRoom');
        }
    });

    // Car selection
    document.querySelectorAll('.car-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.car-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
            selectedCar = parseInt(e.target.dataset.car);
            updatePlaceBetButton();
        });
    });

    // Quick bet buttons
    document.getElementById('bet50').addEventListener('click', () => {
        document.getElementById('betInput').value = 50;
    });
    document.getElementById('bet100').addEventListener('click', () => {
        document.getElementById('betInput').value = 100;
    });
    document.getElementById('bet250').addEventListener('click', () => {
        document.getElementById('betInput').value = 250;
    });
    document.getElementById('bet500').addEventListener('click', () => {
        document.getElementById('betInput').value = 500;
    });

    // Place bet
    document.getElementById('placeBetBtn').addEventListener('click', () => {
        const betAmount = parseInt(document.getElementById('betInput').value);

        if (!selectedCar && selectedCar !== 0) {
            showNotification('Select a car first!', 'error');
            return;
        }

        if (betAmount < 10) {
            showNotification('Minimum bet is $10', 'error');
            return;
        }

        if (betAmount > playerData.money) {
            showNotification('Not enough money!', 'error');
            return;
        }

        socket.emit('placeBet', {
            amount: betAmount,
            carIndex: selectedCar
        });

        showNotification('Bet placed!', 'success');
    });

    // Start race
    document.getElementById('startRaceBtn').addEventListener('click', () => {
        socket.emit('startRace');
    });
});

// Show main menu
function showMainMenu() {
    switchScreen('mainMenu');
    document.getElementById('currentPlayerName').textContent = playerData.name;
    document.getElementById('currentMoney').textContent = playerData.money;

    // Connect to server
    if (!socket) {
        socket = io();
        setupSocketListeners();
    }

    // Request rooms update
    socket.emit('getRooms');
}

// Setup socket listeners
function setupSocketListeners() {
    socket.on('roomsUpdate', (rooms) => {
        updateRoomsList(rooms);
    });

    socket.on('roomState', (state) => {
        updateGameRoom(state);
    });

    socket.on('raceStart', () => {
        showNotification('Race starting!', 'success');
        resetCarPositions();
    });

    socket.on('raceUpdate', (positions) => {
        updateCarPositions(positions);
    });

    socket.on('raceEnd', (data) => {
        handleRaceEnd(data);
    });

    socket.on('leftRoom', (data) => {
        playerData.money = data.money;
        savePlayerData();
        currentRoom = null;
        showMainMenu();
        showNotification('Left room', 'info');
    });

    socket.on('error', (message) => {
        showNotification(message, 'error');
    });
}

// Update rooms list
function updateRoomsList(rooms) {
    for (let roomId in rooms) {
        const roomCard = document.querySelector(`[data-room="${roomId}"]`);
        if (roomCard) {
            const info = rooms[roomId];
            const playerCount = roomCard.querySelector('.player-count');
            const status = roomCard.querySelector('.room-status');
            const btn = roomCard.querySelector('.btn-join');

            playerCount.textContent = `${info.playerCount}/4 Players`;
            
            if (info.racing) {
                status.textContent = '🔴';
                roomCard.classList.add('racing');
            } else {
                status.textContent = '🟢';
                roomCard.classList.remove('racing');
            }

            if (info.playerCount >= 4) {
                btn.disabled = true;
                btn.textContent = 'FULL';
                roomCard.classList.add('full');
            } else {
                btn.disabled = false;
                btn.textContent = 'JOIN ROOM';
                roomCard.classList.remove('full');
            }
        }
    }
}

// Join room
function joinRoom(roomId) {
    currentRoom = roomId;
    socket.emit('joinRoom', {
        roomId: roomId,
        playerData: playerData
    });
    
    switchScreen('gameRoom');
    document.getElementById('roomTitle').textContent = roomId.toUpperCase().replace('ROOM', 'ROOM ');
    document.getElementById('gameMoney').textContent = playerData.money;
}

// Update game room
function updateGameRoom(state) {
    const playersList = document.getElementById('playersList');
    playersList.innerHTML = '';

    const carColors = ['#FF4444', '#4444FF', '#44FF44', '#FFAA00'];
    const carNames = ['RED', 'BLUE', 'GREEN', 'ORANGE'];

    for (let playerId in state.players) {
        const player = state.players[playerId];
        const isCurrentPlayer = playerId === socket.id;

        const playerCard = document.createElement('div');
        playerCard.className = 'player-card' + (isCurrentPlayer ? ' current' : '');
        playerCard.style.borderLeftColor = carColors[player.carIndex];

        let betInfo = 'No bet';
        if (player.bet > 0) {
            betInfo = `$${player.bet} on ${carNames[player.betCar]}`;
        }

        playerCard.innerHTML = `
            <h4>${player.name} ${isCurrentPlayer ? '(You)' : ''}</h4>
            <p>🏎️ Car: ${carNames[player.carIndex]}</p>
            <p>💰 Money: $${player.money}</p>
            <p>🎲 Bet: ${betInfo}</p>
        `;

        playersList.appendChild(playerCard);

        // Update current player money
        if (isCurrentPlayer) {
            playerData.money = player.money;
            document.getElementById('gameMoney').textContent = player.money;
            document.getElementById('currentMoney').textContent = player.money;
            savePlayerData();
        }
    }

    // Update start race button
    const allPlayersReady = Object.values(state.players).every(p => p.bet > 0);
    document.getElementById('startRaceBtn').disabled = !allPlayersReady || state.racing;
}

// Update place bet button
function updatePlaceBetButton() {
    const btn = document.getElementById('placeBetBtn');
    btn.disabled = selectedCar === null;
}

// Reset car positions
function resetCarPositions() {
    document.querySelectorAll('.car').forEach(car => {
        car.style.left = '20px';
        car.classList.remove('winner');
    });
}

// Update car positions
function updateCarPositions(positions) {
    const track = document.getElementById('raceTrack');
    const trackWidth = track.offsetWidth - 100;

    positions.forEach((position, index) => {
        const car = document.querySelector(`[data-car="${index}"] .car`);
        const progress = Math.min(position / 100, 1);
        car.style.left = (20 + progress * trackWidth) + 'px';
    });
}

// Handle race end
function handleRaceEnd(data) {
    const carColors = ['#FF4444', '#4444FF', '#44FF44', '#FFAA00'];
    const carNames = ['RED', 'BLUE', 'GREEN', 'ORANGE'];

    // Highlight winner
    const winnerCar = document.querySelector(`[data-car="${data.winner}"] .car`);
    winnerCar.classList.add('winner');

    showNotification(`${carNames[data.winner]} car wins! 🏆`, 'success');

    // Update player data
    const myPlayer = data.players[socket.id];
    if (myPlayer) {
        const won = myPlayer.betCar === data.winner;
        if (won) {
            showNotification(`You won $${myPlayer.bet * 2}! 💰`, 'success');
        } else {
            showNotification(`You lost $${myPlayer.bet} 😢`, 'error');
        }
    }

    // Reset selections
    document.querySelectorAll('.car-btn').forEach(btn => btn.classList.remove('selected'));
    selectedCar = null;
    document.getElementById('betInput').value = 100;
    updatePlaceBetButton();
}